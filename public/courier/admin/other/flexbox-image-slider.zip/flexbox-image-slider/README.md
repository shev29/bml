# Flexbox Image Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/kathykato/pen/prEmKe](https://codepen.io/kathykato/pen/prEmKe).

A simple Flexbox image slider/carousel made with vanilla JavaScript.